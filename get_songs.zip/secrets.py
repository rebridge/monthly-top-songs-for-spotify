# Make sure to fill in your spotify information
spotify_user_id = ""
spotify_password = ""
